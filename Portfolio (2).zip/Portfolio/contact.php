<?php
// Inclure le fichier autoload de Swift Mailer
require 'vendor/autoload.php';

// Vérifier si le formulaire a été soumis
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Récupérer les données du formulaire
    $nom = htmlspecialchars($_POST["nom"]);
    $prenom = htmlspecialchars($_POST["prenom"]);
    $email = htmlspecialchars($_POST["email"]);
    $telephone = htmlspecialchars($_POST["telephone"]);
    $message = htmlspecialchars($_POST["message"]);

    // Variables pour les informations d'identification Gmail
    $smtpUsername = 'lisa.dvlt@gmail.com';
    $smtpPassword = 'coquillage1511';

    // Configuration des paramètres SMTP
    $smtpHost = 'smtp.gmail.com';
    $smtpPort = 587;
    $smtpEncryption = 'tls';

    // Configuration des options SMTP
    $smtpOptions = [
        'ssl' => [
            'verify_peer' => false,
            'verify_peer_name' => false,
            'allow_self_signed' => true
        ]
    ];

    // Configuration du transport SMTP
    $transport = new Swift_SmtpTransport($smtpHost, $smtpPort, $smtpEncryption);
    $transport->setUsername($smtpUsername);
    $transport->setPassword($smtpPassword);
    $transport->setStreamOptions($smtpOptions);

    // Création du mailer SMTP
    $mailer = new Swift_Mailer($transport);

    // Création du message
    $messageObj = new Swift_Message('Nouveau message depuis le formulaire de contact');
    $messageObj->setFrom([$smtpUsername => 'Votre Nom']);
    $messageObj->setTo(['lisa.dvlt@gmail.com']);
    $messageObj->setBody("Nom: $nom\nPrénom: $prenom\nEmail: $email\nTéléphone: $telephone\n\n$message");

    // Envoi de l'e-mail
    if ($mailer->send($messageObj)) {
        echo "Votre message a été envoyé avec succès.";
    } else {
        echo "Une erreur s'est produite lors de l'envoi du message.";
    }
} else {
    // Redirection si le formulaire n'a pas été soumis
    header("Location: contact.html");
    exit;
}
?>
